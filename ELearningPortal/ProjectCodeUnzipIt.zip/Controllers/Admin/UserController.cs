﻿using ELearningPortal.Interfaces.IAdmin;
using ELearningPortal.Models.Authentication;
using ELearningPortal.Services.Admin;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ELearningPortal.Controllers.Admin
{
    public class UserController : Controller
    {
        IUserService userService;
        public UserController(IUserService userService)
        {
            this.userService = userService;
        }
        public IActionResult Index()
        {
            var udata = userService.fetchUsers();
            return View(udata);
        }

        public IActionResult AdminUser()
        {
            var udata = userService.fetchUsers();
            var rdata = userService.fetchRoles();
            var bdata = userService.fetchBranches();
            ViewBag.Role = new SelectList(rdata, "RoleId", "RoleName");
            ViewBag.Branch = new SelectList(bdata, "BranchId", "BranchName");
            return View(udata);
        }

        [HttpPost]
        public IActionResult AdminAddUser(UserViewModel model)
        {
            userService.addUsers(model);
            return RedirectToAction("AdminUser");
        }

        public IActionResult EditUser(int id)
        {
            var user = userService.GetUserById(id);
            var rdata = userService.fetchRoles();
            var bdata = userService.fetchBranches();
            ViewBag.Role = new SelectList(rdata, "RoleId", "RoleName");
            ViewBag.Branch = new SelectList(bdata, "BranchId", "BranchName");

            return View(user);
        }

        [HttpPost]
        public IActionResult AdminUpdateUser(UserViewModel model)
        {
            userService.updateUsers(model);
            TempData["warningmsg"] = "Emp Updated Successfully!!";            
            return RedirectToAction("AdminUser");
        }

        public IActionResult AdminDelete(int id)
        {
            userService.deleteUsers(id);
            TempData["dangermsg"] = "Emp Deleted Successfully!!";
            return RedirectToAction("AdminUser");
        }
        public IActionResult AdminCourse() { 
            return View();
        }

        public IActionResult AdminLesson()
        {
            return View();
        }

        public IActionResult AdminAttachment()
        {
            return View();
        }

        public IActionResult AdminAssignment()
        {
            return View();
        }
        public IActionResult AdminMCQ()
        {
            return View();
        }
        public IActionResult AdminSubscription()
        {
            return View();
        }

    }
}
