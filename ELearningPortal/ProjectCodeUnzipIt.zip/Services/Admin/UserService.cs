﻿using ELearning.Data;
using ELearningPortal.Interfaces.IAdmin;
using ELearning.Models;
using Microsoft.EntityFrameworkCore;
using ELearning.Models.Authentication;
using ELearningPortal.Models.Authentication;


namespace ELearningPortal.Services.Admin
{
    public class UserService : IUserService
    {
        private readonly AppDbContext db;
        private readonly IWebHostEnvironment env;
        public UserService(AppDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }


        public void addUsers(UserViewModel model)
        {
            if (model.ProfileImage != null) {
                // give path
                string uploadsFolder = Path.Combine(env.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                // diff name
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProfileImage.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                     model.ProfileImage.CopyTo(fileStream);
                }

                string relativeDbPath = "/uploads/" + uniqueFileName;
                var record = new ELearning.Models.Authentication.User
                {
                    ProfileImage = relativeDbPath,
                    RoleId = model.RoleId,
                    BranchId = model.BranchId,
                    FullName = model.FullName,
                    Email = model.Email,
                    PasswordHash = model.Password, 
                    Phone = model.Phone,
                    Gender = model.Gender,
                    Status = model.Status,
                    CreatedAt = DateTime.Now,
                    ModifiedAt = DateTime.Now
                };
                db.Users.Add(record);
                db.SaveChanges();
            }

            
        }

        public void deleteUsers(int id)
        {
            var eudata = db.Users.Find(id);
            if (eudata != null)
            {
                db.Users.Remove(eudata);
                db.SaveChanges();
            }
        }

        public List<Branch> fetchBranches()
        {
            var bdata = db.Branches.ToList();
            return bdata;
        }

        public List<Role> fetchRoles()
        {
            var rdata = db.Roles.ToList();
            return rdata;
        }

        public List<ELearning.Models.Authentication.User> fetchUsers()
        {
            var udata = db.Users.Include(x=> x.Role).Include(y=> y.Branch).ToList();
            return udata;
        }

        public UserViewModel GetUserById(int id)
        {
            var user = db.Users.Find(id);

            if (user == null)
                return null;

            return new UserViewModel
            {
                UserId = user.UserId,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.Phone,
                RoleId = user.RoleId,
                BranchId = user.BranchId,
                Gender = user.Gender,
                Status = user.Status,
                ModifiedAt = DateTime.Now

            };
        }

        public void updateUsers(UserViewModel model)
        {
            var user = db.Users.Find(model.UserId);

            if (user != null)
            {
                user.FullName = model.FullName;
                user.Email = model.Email;
                user.Phone = model.Phone;
                user.RoleId = model.RoleId;
                user.BranchId = model.BranchId;
                user.Gender = model.Gender;
                user.Status = model.Status;
                user.ModifiedAt = DateTime.Now;
            }

            if (model.ProfileImage != null)
            {
                // Upload image
            }

            db.SaveChanges();
        }
    }
}
